
package com.bykeno.fitlab
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bykeno.fitlab.databinding.ActivityMainBinding
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.records.StepsRecord
import kotlinx.coroutines.*
import java.time.Instant
import java.time.temporal.ChronoUnit

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var isSyncing = false
    private var job: Job? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.speedSlider.addOnChangeListener { _, v, _ ->
            binding.speedValue.text = "${"%.1f".format(v)} km/h"
        }
        binding.startBtn.setOnClickListener {
            if(isSyncing) stopSync() else startSync()
        }
    }
    fun startSync() {
        isSyncing = true
        binding.startBtn.text = "STOP SYNC"
        binding.statusText.text = "bykeno sync aktivdir - Google Fit-e yazilir"
        val client = if(HealthConnectClient.getSdkStatus(this)==HealthConnectClient.SDK_AVAILABLE) HealthConnectClient.getOrCreate(this) else null
        val stepsPerMin = binding.speedSlider.value * 130
        job = CoroutineScope(Dispatchers.IO).launch {
            var total = 0
            while(isActive){
                try{
                    val now = Instant.now()
                    val rec = StepsRecord(count = stepsPerMin.toLong(), startTime = now.minus(1, ChronoUnit.MINUTES), endTime = now, startZoneOffset = null, endZoneOffset = null)
                    client?.insertRecords(listOf(rec))
                    total += stepsPerMin.toInt()
                    withContext(Dispatchers.Main){ binding.addedSteps.text = "$total addim elave edildi - bykeno" }
                }catch(e:Exception){ e.printStackTrace() }
                delay(60000)
            }
        }
    }
    fun stopSync(){ isSyncing=false; binding.startBtn.text="START SYNC"; job?.cancel() }
}
