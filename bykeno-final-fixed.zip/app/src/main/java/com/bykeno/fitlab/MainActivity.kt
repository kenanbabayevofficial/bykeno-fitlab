
package com.bykeno.fitlab
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.StepsRecord
import com.bykeno.fitlab.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import java.time.Instant
import java.time.ZoneOffset

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var isSyncing = false
    private var job: Job? = null
    private var total = 0
    private var healthClient: HealthConnectClient? = null
    private val permissions = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getWritePermission(StepsRecord::class)
    )
    private lateinit var requestPermissionsLauncher: androidx.activity.result.ActivityResultLauncher<Set<String>>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.speedSlider.addOnChangeListener { _, v, _ ->
            binding.speedValue.text = String.format("%.1f km/h", v)
        }

        // Permission launcher
        requestPermissionsLauncher = registerForActivityResult(PermissionController.createRequestPermissionResultContract()) { granted ->
            if(granted.containsAll(permissions)) {
                Toast.makeText(this, "Health Connect izni verildi ✅", Toast.LENGTH_SHORT).show()
                reallyStartSync()
            } else {
                Toast.makeText(this, "Health Connect icazesi lazimdir! Health Connect app-da bykeno-ya icaze ver", Toast.LENGTH_LONG).show()
            }
        }

        initHealthClient()

        binding.startBtn.setOnClickListener {
            if(isSyncing) stopSync() else startSync()
        }
    }

    private fun initHealthClient() {
        val status = HealthConnectClient.getSdkStatus(this)
        if(status == HealthConnectClient.SDK_AVAILABLE) {
            healthClient = HealthConnectClient.getOrCreate(this)
        } else {
            binding.statusText.text = "Health Connect tapilmadi - amma lokal sayacaq isleyecek"
            healthClient = null
        }
    }

    fun startSync() {
        if(healthClient != null) {
            CoroutineScope(Dispatchers.IO).launch {
                val granted = healthClient!!.permissionController.getGrantedPermissions()
                withContext(Dispatchers.Main) {
                    if(!granted.containsAll(permissions)) {
                        requestPermissionsLauncher.launch(permissions)
                    } else {
                        reallyStartSync()
                    }
                }
            }
        } else {
            reallyStartSync()
        }
    }

    fun reallyStartSync() {
        isSyncing = true
        binding.startBtn.text = "STOP SYNC"
        binding.statusText.text = "bykeno sync aktivdir - Google Fit-e yazilir"

        val speed = binding.speedSlider.value
        // daha suretli gorsun deye: 5 km/h = 100 addim/deq ~ 1.6 addim/saniye
        // Istifadeci tez gorsun deye saniyede guncelleyeceyik
        val stepsPerSecond = (speed * 2.2).toInt().coerceAtLeast(1)

        job = CoroutineScope(Dispatchers.IO).launch {
            while(isActive){
                try{
                    val now = Instant.now()
                    val start = now.minusSeconds(5)
                    val stepsInChunk = (stepsPerSecond * 5)

                    if(healthClient != null) {
                        try {
                            val rec = StepsRecord(
                                count = stepsInChunk.toLong(),
                                startTime = start,
                                endTime = now,
                                startZoneOffset = ZoneOffset.UTC,
                                endZoneOffset = ZoneOffset.UTC
                            )
                            healthClient!!.insertRecords(listOf(rec))
                        } catch(e: Exception) { e.printStackTrace() }
                    }

                    total += stepsInChunk
                    withContext(Dispatchers.Main){
                        binding.addedSteps.text = "$total addim"
                        binding.statusText.text = "bykeno sync aktivdir - $total addim yazildi ✅"
                    }
                }catch(e: Exception){ e.printStackTrace() }
                delay(5000) // 5 saniyeden bir
            }
        }
    }

    fun stopSync(){
        isSyncing=false
        binding.startBtn.text="START SYNC"
        binding.statusText.text = "Dayandirildi - $total addim yazildi"
        job?.cancel()
    }
}
